/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp;

import java.util.logging.Level;
import java.util.logging.Logger;
import tp.Interfaz_1;

/**
 *
 * Se implementa la clase lista enlazada circular para almacenar las canciones
 */
public class listaEnlazada {
    int tamaño = 0;
    Nodo cabeza, ultimo, actual, auxiliar;
    
    
  
    
    class Nodo {
        int dura =0;
        String datosCancion= null;
        String artista,genero,cancion,albun,duracion;
        String dato = null;
        Nodo siguiente = null;
        Nodo anterior = null;
    }
    
    /**
     * 
     *metodo que permite agregar una cancion a la lista
     */
    public void agregar (String cancion){
        Nodo nuevo = new Nodo();
        nuevo.dato = cancion;
        
        if (tamaño == 0){
            cabeza = nuevo;
            cabeza.siguiente = cabeza;
            cabeza.anterior = cabeza;
            ultimo = cabeza;
            actual = ultimo;
            tamaño +=1;
        }
        else{
            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;
            ultimo = nuevo;
            tamaño +=1;
            ultimo.siguiente = cabeza;
            cabeza.anterior = ultimo;
            
            actual=cabeza;
        }
    }
    
    /**
     * 
     * metodo que elimina una cancion de la lista
     */
    public void eliminar(String cancion){
        Nodo nuevo = new Nodo();
        nuevo = cabeza;
        for(int i=1; i<tamaño;i++){
            System.out.println("1");
            if(nuevo.dato == null ? cancion == null : nuevo.dato.equals(cancion)){
                System.out.println("123");
                if(ultimo==nuevo){
                    ultimo=ultimo.anterior;
                }
                if(cabeza==nuevo){
                    cabeza=cabeza.siguiente;
                }
                actual=nuevo.anterior;
                nuevo=nuevo.siguiente;
                nuevo.anterior=actual;
                actual.siguiente=nuevo;
                actual=nuevo;
                tamaño-=1;
            }
        }
        if (tamaño==1){
            eliminarLista();
        }
    }
    
    public void eliminarLista(){
        tamaño=0;
    }
}
