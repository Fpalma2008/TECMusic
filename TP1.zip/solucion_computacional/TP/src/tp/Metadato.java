
package tp;

/**
 * libreria para extraer los datos de las canciones
 * En este caso se utilizo jid3lib
 */
import java.io.File;
import java.io.IOException;
import java.util.Map;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import org.farng.mp3.MP3File;
import org.farng.mp3.TagException;
import org.farng.mp3.id3.AbstractID3v2;

/**
 * 
 * clase principal para extraer la informacion de la cancion
 */

public class Metadato {
    
    AbstractID3v2 id3;
        String artist; 
        String song;
        String album;
        String letra;
        String genre;
        int duration;
        int songSize;
        int min1,sec1;

        public void Metadato(String ruta) throws IOException, TagException { //Constructor de la clase Metadatos
       
            MP3File mp3 = new MP3File(ruta); //Crea un nuevo objeto llamando una clase de la libreria
            id3 = mp3.getID3v2Tag(); //Usa el ojeto creado para obtener los metadatos de la cancionn dada en la ruta
        }
        
        /**
         * 
         * Metodo para extraer la duracion de la cancion 
         */
        public String duracionCancion(String dato) throws UnsupportedAudioFileException, IOException {
            File file = new File(dato);
            AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(file);
            if (fileFormat instanceof AudioFileFormat) {
                Map<?, ?> properties = ((AudioFileFormat) fileFormat).properties();
                String key = "duration";
                Long microseconds = (Long) properties.get(key);
                int mili = (int) (microseconds / 1000);
                int sec = (mili / 1000) % 60;
                int min = (mili / 1000) / 60;
                min1=min;
                sec1=sec;
                return min + ":" + sec;
            } else {
                throw new UnsupportedAudioFileException();
            }

        }
     
        
        /**
         * 
         * metodo para extraer el artista que interpreta la cancion
         */
        public String artista() { 
            this.artist = id3.getLeadArtist();
            return this.artist; 
        }
        
        /**
         * 
         * metodo para extraer el nombre de la cancion
         */
       
        public String cancion() { 
            this.song = id3.getSongTitle();    
            return song; 
        }
    
        
        /**
         * 
         * metodo para extraer el album de la cancion
         */
        public String album() { 
            this.album = id3.getAlbumTitle();
            return album; 
        }
        
        
        /**
         * 
         * metodo para extraer el genero de la cancion
         */
        
        public String genero() { 
            this.genre = id3.getSongGenre();
            return genre; 
        }
        
        
        /**
         * 
         * metodos para cambiar los datos de la cancion
         */
        
        public void setgenero(String gen) { 
            id3.setSongGenre(gen);
        }
        
        public void setcancion(String can) { 
            id3.setSongTitle(can);
        }
        
        public void setalbum(String alb) { 
            id3.setAlbumTitle(alb);
        }
        
        public void setartista(String art) { 
            id3.setLeadArtist(art);
        }
}


