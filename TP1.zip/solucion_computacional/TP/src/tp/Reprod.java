
package tp;

/**
 * libreria para reproducir archivos mp3
 */
import java.io.File;
import javazoom.jlgui.basicplayer.BasicPlayer;

/**
 * se crea la clase principal reprod
 * 
 */
public class Reprod {
    public BasicPlayer reproductor;
    
    /**
     * Constructor de la clase
     */
    public Reprod() {
        reproductor = new BasicPlayer();
    }
    
    /**
     * 
     * Metodo para abrir el archivo y obtener la ruta de la cancion
     */
    
    public void abrirArchivo(String ruta) throws Exception {
        reproductor.open(new File(ruta));
    }
    
    /**
     * 
     * Metodo para reproducir la cancion
     */
    
    public void play() throws Exception {
        reproductor.play();
    }
    
    /**
     * 
     * Metodo para pausar la reproduccion de la cancion
     */
    
    public void pausa() throws Exception {
        reproductor.pause();
    }
    
    /**
     * 
     * Metodo para detener la reproduccion de la cancion
     */
    
    
    public void stop() throws Exception {
        reproductor.stop();
    }

    /**
     * 
     * Metodo para continuar con la reproduccion de la cancion
     */
    
    public void continuar() throws Exception {
        reproductor.resume();
    }
}
