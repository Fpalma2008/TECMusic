package tp;

import java.io.IOException; 
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JFileChooser; /** 
 * Libreria para importar la cancion desde la computadora
 */

import javax.swing.filechooser.FileNameExtensionFilter; 
import org.farng.mp3.TagException;

/**
 * Clase principal con la que se crea la interfaz
 * 
 */
public class Interfaz_1 extends javax.swing.JFrame { 

    int num = 1;
    listaEnlazada listaTotal = new listaEnlazada();
    /** 
     * se importa la clase listaEnlazada por medio de
     * la creacion de un nuevo objeto llamado listaTotal
     * 
     */
    listaEnlazada lista = new listaEnlazada();
    Reprod rep = new Reprod();
    Metadato met = new Metadato();
    int bandera = 1;
    int indice = 0;
    int art1=0, alb1=0, gen1=0;
    
    private FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivo de audio MP3", "MP3");

    
    public Interfaz_1() {
        initComponents();
    }
    /** 
     * Se implementa la libreria que extrae el metadato y se hace la conexion con interfaz 
     * para mostrar el artista, genero, album, y duracion de la cancion
     */
    public void artista(String dato) throws IOException, TagException{
        met.Metadato(dato);
        String art;
        boolean artist=true;
        if(met.artista()==""){
            art="desconocido";
        }else{
            art=(String)met.artista();
        }
        for(int i=0;i<art1;i++){
            String temporal =(String) cbArtista.getItemAt(i);
            if(temporal == null ? art == null : temporal.equals(art)){
                artist=false;
            }
        }
        if(artist==true){
            cbArtista.addItem(art);
            art1+=1;
        }
    }
    
    public void Genero(String dato) throws IOException, TagException{
        met.Metadato(dato);
        String art;
        boolean artist=true;
        if(met.genero()==""){
            art="desconocido";
        }else{
            art=(String)met.genero();
        }
        for(int i=0;i<art1;i++){
            String temporal =(String) cbGenero.getItemAt(i);
            if(temporal == null ? art == null : temporal.equals(art)){
                artist=false;
            }
        }
        if(artist==true){
            cbGenero.addItem(art);
            art1+=1;
        }
    }
    public void albunn(String dato) throws IOException, TagException{
        met.Metadato(dato);
        String art;
        boolean artist=true;
        
        if(met.album()==""){
            art="desconocido";
        }else{
            art=(String)met.album();
        }
        for(int i=0;i<art1;i++){
            String temporal =(String) cbAlbunes.getItemAt(i);
            if(temporal == null ? art == null : temporal.equals(art)){
                artist=false;
            }
        }
        if(artist==true){
            cbAlbunes.addItem(art);
            alb1+=1;
        }
    }
    
    public void tiempo(int temp) throws InterruptedException {
        Thread.sleep(temp);
    }

    public void dataCancion() throws IOException, TagException, UnsupportedAudioFileException {
        cbArtista.removeAllItems();
        cbGenero.removeAllItems();
        cbAlbunes.removeAllItems();
        lista.auxiliar = lista.cabeza;
        listaTotal.auxiliar =listaTotal.cabeza;
        num = 1;
        for (int i = 0; lista.tamaño > i; i++) {
            met.Metadato(lista.auxiliar.dato);
            lista.auxiliar.datosCancion = ((String.valueOf(num)) + "- " + (lista.auxiliar.cancion = met.cancion()) + " // " + (lista.auxiliar.albun = met.album()) + " // " + (lista.auxiliar.artista = met.artista()) + " // " + (lista.auxiliar.genero = met.genero()) + " // " + (lista.auxiliar.duracion = met.duracionCancion(lista.auxiliar.dato)));
            lista.auxiliar.dura = (((met.min1 * 60) + met.sec1) * 1000);
            lista.auxiliar = lista.auxiliar.siguiente;
            num += 1;
        }
        
        for (int i = 0; listaTotal.tamaño > i; i++) {
            artista(listaTotal.auxiliar.dato);
            albunn(listaTotal.auxiliar.dato);
            Genero(listaTotal.auxiliar.dato);
            met.Metadato(listaTotal.auxiliar.dato);
            listaTotal.auxiliar.datosCancion = ((String.valueOf(num)) + "- " + (listaTotal.auxiliar.cancion = met.cancion()) + " // " + (listaTotal.auxiliar.albun = met.album()) + " // " + (listaTotal.auxiliar.artista = met.artista()) + " // " + (listaTotal.auxiliar.genero = met.genero()) + " // " + (listaTotal.auxiliar.duracion = met.duracionCancion(listaTotal.auxiliar.dato)));
            listaTotal.auxiliar.dura = (((met.min1 * 60) + met.sec1) * 1000);
            listaTotal.auxiliar = listaTotal.auxiliar.siguiente;
            num += 1;
        }
    }
    /**
     * metodo para refrescar el combobox y actualizarlo con las canciones que se agregan
     * 
     */

    public void refrescarBox() throws IOException, TagException {
        lista.auxiliar = lista.cabeza;
        cb.removeAllItems();
        for (int i = 0; lista.tamaño > i; i++) {
            cb.addItem(lista.auxiliar.datosCancion);
            lista.auxiliar = lista.auxiliar.siguiente;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        AgregarCancion = new javax.swing.JButton();
        cb = new javax.swing.JComboBox();
        jButton10 = new javax.swing.JButton();
        cbGenero = new javax.swing.JComboBox();
        cbAlbunes = new javax.swing.JComboBox();
        cbArtista = new javax.swing.JComboBox();
        cbEditar = new javax.swing.JComboBox();
        jSeparator5 = new javax.swing.JSeparator();
        cambioMeta = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(13, 9, 5));

        jPanel1.setBackground(java.awt.Color.black);
        jPanel1.setForeground(new java.awt.Color(17, 9, 9));

        jLabel2.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(53, 147, 200));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("MI MUSICA");

        jButton1.setText("Canciones");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Albumes");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Artistas");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Eliminar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Genero");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Modificar datos");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tp/previous.png"))); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tp/stop.png"))); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tp/play.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tp/rewind.png"))); // NOI18N
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(229, 236, 239));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tp/tecMusicc.png"))); // NOI18N
        jLabel5.setAutoscrolls(true);

        AgregarCancion.setText("Agregar");
        AgregarCancion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarCancionActionPerformed(evt);
            }
        });

        cb.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbActionPerformed(evt);
            }
        });

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tp/pause.png"))); // NOI18N
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        cbGenero.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cbGenero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbGeneroActionPerformed(evt);
            }
        });

        cbAlbunes.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        cbArtista.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cbArtista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbArtistaActionPerformed(evt);
            }
        });

        cbEditar.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Genero", "Artista", "Album", "Cancion" }));

        cambioMeta.setText("Nuevo");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(42, 42, 42)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(31, 31, 31)
                                        .addComponent(cb, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(AgregarCancion, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(cambioMeta, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(9, 9, 9))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(921, 921, 921)
                                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 18, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                                                .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(cbAlbunes, 0, 144, Short.MAX_VALUE)
                                                .addComponent(cbArtista, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addComponent(cbGenero, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator4)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(57, 57, 57)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(cb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(AgregarCancion, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(66, 66, 66)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(42, 42, 42)
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton2)
                                    .addComponent(cbAlbunes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton3)
                                    .addComponent(cbArtista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton5)
                                    .addComponent(cbGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(46, 46, 46)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton6)
                                    .addComponent(cbEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cambioMeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AgregarCancionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarCancionActionPerformed

        JFileChooser dlg = new JFileChooser();
        Metadato MD = new Metadato();
        dlg.setFileFilter(filter);

        int opcion = dlg.showOpenDialog(this);

        if (opcion == JFileChooser.APPROVE_OPTION) {
            String file = dlg.getSelectedFile().getPath();
            String archivo = dlg.getSelectedFile().toString();
            lista.agregar(archivo);
            listaTotal.agregar(archivo);
            
            try {
                this.dataCancion();
            } catch (IOException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (TagException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedAudioFileException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                this.refrescarBox();
            } catch (IOException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (TagException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }//GEN-LAST:event_AgregarCancionActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        try {
            rep.stop();
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
        lista.actual=lista.actual.anterior;
        try {
            rep.abrirArchivo(lista.actual.dato);
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            rep.play();
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        listaTotal.actual =listaTotal.cabeza;
        lista.eliminarLista();
        
        for (int i=0;i<listaTotal.tamaño;i++){
            lista.agregar(listaTotal.actual.dato);
                try {
                    this.dataCancion();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedAudioFileException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    this.refrescarBox();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            listaTotal.actual=listaTotal.actual.siguiente;
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        listaTotal.actual =listaTotal.cabeza;
        lista.eliminarLista();
        String a;
        if((String)cbAlbunes.getSelectedItem()=="desconocido"){
            a="";
        }
        else{
            a=(String)cbAlbunes.getSelectedItem();
        }
        for (int i=0;i<listaTotal.tamaño;i++){
            System.out.println("dasda151515");
            if(listaTotal.actual.albun == null ? a == null : listaTotal.actual.albun.equals(a)){
                lista.agregar(listaTotal.actual.dato);
                System.out.println("dadfs");
                try {
                    this.dataCancion();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedAudioFileException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    this.refrescarBox();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            listaTotal.actual=listaTotal.actual.siguiente;
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void cbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbActionPerformed

    }//GEN-LAST:event_cbActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        /*String b=cambioMeta.getText();
        String a=(String)cbEditar.getSelectedItem();
        String c="";
        lista.auxiliar=lista.cabeza;
        try {
            for (int i=0;i<lista.tamaño;i++){
                if(lista.auxiliar.datosCancion == null ? (String) cb.getSelectedItem() == null : lista.auxiliar.datosCancion.equals((String) cb.getSelectedItem())){
                    c=lista.auxiliar.dato;
                }
                lista.auxiliar=lista.auxiliar.siguiente;
            }
            met.Metadato(c);
            switch(a){
                case "Genero":
                    met.setgenero(b);
                    break;
                case "Artista":
                    met.setartista(b);
                    break;
                case "Album":
                    met.setalbum(b);
                    break;
                case "Cancion":
                    met.setcancion(b);
                    break;
            }
        } catch (IOException ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TagException ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
                this.dataCancion();
            } catch (IOException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (TagException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedAudioFileException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                this.refrescarBox();
            } catch (IOException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (TagException ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }
        */
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        lista.actual = lista.cabeza;
        for (int i = 0; i < lista.tamaño; i++) {
            if (lista.actual.datosCancion == (String) cb.getSelectedItem()) {
                try {
                    rep.abrirArchivo(lista.actual.dato);
                } catch (Exception ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    rep.play();
                } catch (Exception ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                indice = i;
            }
            if (lista.actual == lista.ultimo) {
                lista.actual = lista.cabeza;
            }
            lista.actual = lista.actual.siguiente;

        }

    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        try {
            rep.stop();
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (lista.actual.siguiente == null) {
            lista.actual = lista.ultimo;
        } else {
            lista.actual = lista.actual.siguiente;
        }

        try {
            rep.abrirArchivo(lista.actual.dato);
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            rep.play();
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        try {
            rep.stop();
        } catch (Exception ex) {
            Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        if(bandera==1){
            bandera=2;
            try {
                rep.pausa();
            } catch (Exception ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            bandera=1;
            try {
                rep.continuar();
            } catch (Exception ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
        
          // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void cbGeneroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbGeneroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbGeneroActionPerformed

    private void cbArtistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbArtistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbArtistaActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        listaTotal.actual =listaTotal.cabeza;
        lista.eliminarLista();
        String a;
        if((String)cbArtista.getSelectedItem()=="desconocido"){
            a="";
        }
        else{
            a=(String)cbArtista.getSelectedItem();
        }
        for (int i=0;i<listaTotal.tamaño;i++){
            System.out.println("dasda151515");
            if(listaTotal.actual.artista == null ? a == null : listaTotal.actual.artista.equals(a)){
                lista.agregar(listaTotal.actual.dato);
                System.out.println("dadfs");
                try {
                    this.dataCancion();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedAudioFileException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    this.refrescarBox();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            listaTotal.actual=listaTotal.actual.siguiente;
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        listaTotal.actual =listaTotal.cabeza;
        lista.eliminarLista();
        String a;
        if((String)cbGenero.getSelectedItem()=="desconocido"){
            a="";
        }
        else{
            a=(String)cbGenero.getSelectedItem();
        }
        for (int i=0;i<listaTotal.tamaño;i++){
            System.out.println("dasda151515");
            if(listaTotal.actual.genero == null ? a == null : listaTotal.actual.genero.equals(a)){
                lista.agregar(listaTotal.actual.dato);
                System.out.println("dadfs");
                try {
                    this.dataCancion();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedAudioFileException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    this.refrescarBox();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            listaTotal.actual=listaTotal.actual.siguiente;
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
 /*       lista.actual=lista.cabeza;
        listaTotal.actual=listaTotal.cabeza;
        for(int i=0;i<lista.tamaño;i++){
            if(lista.actual.datosCancion == null ? (String)cb.getSelectedItem() == null : lista.actual.datosCancion.equals((String)cb.getSelectedItem())){
                for(int j=0;i<lista.tamaño;j++){
                    if(listaTotal.actual.dato == lista.actual.dato){
                        listaTotal.eliminar(lista.actual.dato);
                    }
                    listaTotal.actual=listaTotal.actual.siguiente;
                }
                lista.eliminar(lista.actual.dato);
            }
            lista.actual=lista.actual.siguiente;
        }
        if (lista.tamaño==0){
            try {
                rep.stop();
            } catch (Exception ex) {
                Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
                try {
                    this.dataCancion();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedAudioFileException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    this.refrescarBox();
                } catch (IOException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                } catch (TagException ex) {
                    Logger.getLogger(Interfaz_1.class.getName()).log(Level.SEVERE, null, ex);
                }
        */
    }//GEN-LAST:event_jButton4ActionPerformed

    public JButton getAgregarCancion() {
        return AgregarCancion;
    }

    public void setAgregarCancion(JButton AgregarCancion) {
        this.AgregarCancion = AgregarCancion;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz_1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz_1().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AgregarCancion;
    private javax.swing.JTextField cambioMeta;
    private javax.swing.JComboBox cb;
    private javax.swing.JComboBox cbAlbunes;
    private javax.swing.JComboBox cbArtista;
    private javax.swing.JComboBox cbEditar;
    private javax.swing.JComboBox cbGenero;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    // End of variables declaration//GEN-END:variables
}
